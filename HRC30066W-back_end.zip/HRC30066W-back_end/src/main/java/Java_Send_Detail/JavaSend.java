package Java_Send_Detail;

import java.io.*;
import javax.servlet.http.*;

import org.json.JSONArray;

import Java_Send_Detail.InvoiceDetails;

import java.sql.*;
import java.util.*;
import java.util.Date;


public class JavaSend extends HttpServlet {
	
	public void service(HttpServletRequest req, HttpServletResponse res) throws IOException
	{
		res.setContentType("application/json");
		PrintWriter pw = res.getWriter();
		
		try
		{
			String url = "jdbc:mysql://localhost:3306/grey_goose";
			String uname = "root";
			String pwd = "1234";
			String query = "select sl_no, business_code, cust_number, clear_date, "
					+ "buisness_year, doc_id, posting_date, document_create_date, due_in_date, "
					+ "invoice_currency, document_type, posting_id, total_open_amount, baseline_create_date, "
					+ "cust_payment_terms, cust_payment_terms, invoice_id, aging_bucket from winter_internship limit 200;";
			
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con = DriverManager.getConnection(url, uname, pwd);
			
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query); // ResultSet has power to chunk the data from table structure. And it is used in DML.
			
			ArrayList<HashMap> user = new ArrayList<>();
			
			while(rs.next())
			{
				HashMap<String, String> mp = new HashMap<>();
				
				InvoiceDetails inv = new InvoiceDetails();
				
				inv.setSerialNO(rs.getInt("sl_no"));
				inv.setBusinessCode( rs.getString("business_code"));
				inv.setCustNumber(rs.getString("cust_number"));
				inv.setClearDate(rs.getString("clear_date"));
				inv.setBusinessYear(rs.getInt("buisness_year"));
				inv.setDocID(rs.getLong("doc_id"));
				inv.setPostingDate(rs.getString("posting_date"));
				inv.setDocumentCreateDate(rs.getString("document_create_date"));
				inv.setDueInDate(rs.getString("due_in_date"));
				inv.setInvoiceCurrency(rs.getString("invoice_currency"));
				inv.setDocumentType(rs.getString("document_type"));
				inv.setPostingID(rs.getInt("posting_id"));
				inv.setTotalOpenAmount(rs.getDouble("total_open_amount"));
				inv.setBaselineCreateDate(rs.getString("baseline_create_date"));
				inv.setCustPaymentTerms(rs.getString("cust_payment_terms"));
				inv.setInvoiceID(rs.getLong("invoice_id"));
				inv.setAgingBucket(rs.getString("aging_bucket"));
				
				
				mp.put("sl_no", String.valueOf(inv.getSerialNO()));
				mp.put("business_code", inv.getBusinessCode());
				mp.put("cust_number", inv.getCustNumber());
				mp.put("clear_date", inv.getClearDate());
				mp.put("business_year", String.valueOf(inv.getBusinessYear()));
				mp.put("doc_id", String.valueOf(inv.getDocID()));
				mp.put("posting_date", inv.getPostingDate());
				mp.put("document_create_date", inv.getDocumentCreateDate());
				mp.put("due_in_date", inv.getDueInDate());
				mp.put("invoice_currency", inv.getInvoiceCurrency());
				mp.put("document_type", inv.getDocumentType());
				mp.put("posting_id", String.valueOf(inv.getPostingID()));
				mp.put("total_open_amount", String.valueOf(inv.getTotalOpenAmount()));
				mp.put("baseline_create_date", inv.getBaselineCreateDate());
				mp.put("cust_payment_terms", inv.getCustPaymentTerms());
				mp.put("invoice_id", String.valueOf(inv.getInvoiceID()));
				mp.put("aging_bucket", inv.getAgingBucket());

				
	            user.add(mp);
			}
			JSONArray userjson = new JSONArray(user);
			pw.println(userjson);
		}
		catch(Exception e)
		{
			pw.println(e);
		}
	}
	
}
