import { createContext } from "react";

const ActionContext = createContext();

export default ActionContext;
